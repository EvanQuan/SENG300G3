class H { int i; }

package foo;

import C;

class E {public foo.E  foo(C c){ foo.E e = new E();return new foo.E();}}

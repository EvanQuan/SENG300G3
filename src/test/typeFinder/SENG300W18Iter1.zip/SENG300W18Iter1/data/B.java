interface B {public C foo(B b);}

class D {
    public B foo(B b) {
	B b = new B();
	return new C();
    }

    class E {
	public E bar() {return new E();}
    }
}

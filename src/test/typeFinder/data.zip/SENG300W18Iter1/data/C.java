class C {public B  foo(B b){ B b = new B();return new C();}}
